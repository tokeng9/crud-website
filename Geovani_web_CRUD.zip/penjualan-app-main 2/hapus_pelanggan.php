<?php
include 'koneksi.php';
$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nama = $_POST['nama_pelanggan'];
  $alamat = $_POST['alamat'];
  $telepon = $_POST['telepon'];

  $stmt = $koneksi->prepare("UPDATE pelanggan SET nama_pelanggan=?, alamat=?, telepon=? WHERE id_pelanggan=?");
  $stmt->bind_param("sssi", $nama, $alamat, $telepon, $id);
  $stmt->execute();

  header("Location: tampil_pelanggan.php");
  exit;
}

$stmt = $koneksi->prepare("SELECT * FROM pelanggan WHERE id_pelanggan=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Ubah Pelanggan</title>
</head>
<body style="font-family: Arial, sans-serif; padding: 20px;">
  <div style="max-width: 500px; margin: auto;">
    <h3 style="margin-bottom: 20px;">Ubah Pelanggan</h3>
    <form method="post" style="display: flex; flex-direction: column; gap: 10px;">
      <input type="text" name="nama_pelanggan" value="<?= htmlspecialchars($data['nama_pelanggan']) ?>" required>
      <textarea name="alamat" required><?= htmlspecialchars($data['alamat']) ?></textarea>
      <input type="text" name="telepon" value="<?= htmlspecialchars($data['telepon']) ?>" required>
      <button type="submit" style="padding: 8px; background-color: #ffc107; color: black; border: none; border-radius: 4px;">Simpan Perubahan</button>
      <a href="tampil_pelanggan.php" style="text-align: center; display: inline-block; padding: 8px; background-color: #6c757d; color: white; text-decoration: none; border-radius: 4px;">Kembali</a>
    </form>
  </div>
</body>
</html>
