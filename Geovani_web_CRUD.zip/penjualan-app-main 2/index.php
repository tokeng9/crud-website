<?php
// Include koneksi ke database (sesuaikan dengan file koneksi.php Anda)
include 'koneksi.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
      padding: 40px;
      text-align: center;
    }

    h1 {
      margin-bottom: 30px;
    }

    .menu {
      display: flex;
      justify-content: center;
      gap: 20px;
      flex-wrap: wrap;
    }

    .card {
      background-color: white;
      border-radius: 10px;
      padding: 20px;
      width: 200px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      text-decoration: none;
      color: #333;
      transition: transform 0.2s ease;
    }

    .card:hover {
      transform: scale(1.05);
      background-color: #e9ecef;
    }

    .card h3 {
      margin-bottom: 10px;
    }
  </style>
</head>
<body>

  <h1>Dashboard</h1>
  
  <!-- Menu dengan tiga pilihan -->
  <div class="menu">
    <a href="?menu=barang" class="card">
      <h3>Data Barang</h3>
      <p>Lihat & Kelola Barang</p>
    </a>
    <a href="?menu=pelanggan" class="card">
      <h3>Data Pelanggan</h3>
      <p>Lihat & Kelola Pelanggan</p>
    </a>
    <a href="?menu=penjualan" class="card">
      <h3>Data Penjualan</h3>
      <p>Lihat & Kelola Penjualan</p>
    </a>
  </div>

  <!-- Konten Dinamis berdasarkan pilihan menu -->
  <div style="margin-top: 30px;">
    <?php
    // Cek parameter menu yang dikirimkan melalui URL
    if (isset($_GET['menu'])) {
        $menu = $_GET['menu'];

        // Menampilkan konten sesuai pilihan menu
        if ($menu == 'barang') {
            include 'tampil_barang.php';  // Tampilkan Data Barang
        } elseif ($menu == 'pelanggan') {
            include 'tampil_pelanggan.php';  // Tampilkan Data Pelanggan
        } elseif ($menu == 'penjualan') {
            include 'tampil_penjualan.php';  // Tampilkan Data Penjualan
        } else {
            echo "<p>Menu tidak ditemukan.</p>";
        }
    } else {
        echo "<h4>Pilih menu di atas untuk melihat data.</h4>";
    }
    ?>
  </div>

</body>
</html>
