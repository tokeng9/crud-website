<?php
$host = "localhost";
$user = "root";
$pass = "root"; // default password MAMP
$db   = "db_penjualan";
$port = 8888;   // port MySQL di MAMP

$koneksi = mysqli_connect($host, $user, $pass, $db, $port);

if (!$koneksi) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}
?>
