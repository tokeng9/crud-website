<?php
include 'koneksi.php';
$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nama = $_POST['nama_pelanggan'];
  $alamat = $_POST['alamat'];

  $stmt = $koneksi->prepare("UPDATE pelanggan SET nama_pelanggan=?, alamat=? WHERE id_pelanggan=?");
  $stmt->bind_param("ssi", $nama, $alamat, $id);
  $stmt->execute();

  header("Location: tampil_pelanggan.php");
  exit;
}

$stmt = $koneksi->prepare("SELECT * FROM pelanggan WHERE id_pelanggan=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();
?>
<!-- HTML form hanya input nama & alamat -->
