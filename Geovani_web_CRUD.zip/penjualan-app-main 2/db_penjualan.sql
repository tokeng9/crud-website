-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 24, 2025 at 03:44 AM
-- Server version: 8.0.40
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_penjualan`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` int NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `harga` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `harga`) VALUES
(2, 'Mouse Logitech', 150000),
(3, 'Keyboard Rexus', 200000),
(4, 'Monitor Samsung', 3000000),
(5, 'Headphone Sony', 500000),
(6, 'Flashdisk Kingston', 100000),
(7, 'Printer HP', 1500000),
(8, 'Speaker Bose', 2500000),
(9, 'Tablet Samsung', 3500000),
(10, 'Kabel HDMI', 50000),
(11, 'Modem TP-Link', 300000),
(12, 'Router D-Link', 400000),
(13, 'External Harddisk WD', 1200000),
(14, 'VGA Card MSI', 1600000),
(15, 'SSD Samsung', 1800000),
(16, 'Mousepad Razer', 150000),
(17, 'Keyboard Logitech', 600000),
(18, 'Laptop HP', 8000000),
(19, 'Smartphone Xiaomi', 3500000),
(20, 'Smartwatch Apple', 2500000),
(21, 'Kamera Canon', 8000000),
(22, 'Kipas Angin Panasonic', 350000),
(23, 'Speaker JBL', 1500000),
(24, 'Projector Epson', 5000000),
(25, 'Headset Razer', 1000000),
(26, 'AC Daikin', 7000000),
(27, 'Mesin Cuci Panasonic', 4000000),
(28, 'Kulkas LG', 6000000),
(29, 'Microwave Sharp', 1000000),
(30, 'Air Purifier Xiaomi', 2000000);

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int NOT NULL,
  `no_pelanggan` varchar(10) DEFAULT NULL,
  `nama_pelanggan` varchar(100) DEFAULT NULL,
  `alamat` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `no_pelanggan`, `nama_pelanggan`, `alamat`) VALUES
(1, 'PL001', 'Andi Saputra', 'Jl. Melati No.1'),
(2, 'PL002', 'Budi Hartono', 'Jl. Kenanga No.2'),
(3, 'PL003', 'Citra Ayu', 'Jl. Mawar No.3'),
(4, 'PL004', 'Dewi Lestari', 'Jl. Anggrek No.4'),
(5, 'PL005', 'Eko Prasetyo', 'Jl. Flamboyan 5');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `id_penjualan` int NOT NULL,
  `faktur` varchar(20) NOT NULL,
  `no_pelanggan` int NOT NULL,
  `tanggal_penjualan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`id_penjualan`, `faktur`, `no_pelanggan`, `tanggal_penjualan`) VALUES
(1, 'F001', 1, '2025-04-01'),
(2, 'F002', 2, '2025-04-02'),
(3, 'F003', 3, '2025-04-03');

-- --------------------------------------------------------

--
-- Table structure for table `tb_barang`
--

CREATE TABLE `tb_barang` (
  `id` int NOT NULL,
  `nama` varchar(30) NOT NULL,
  `harga` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`),
  ADD UNIQUE KEY `no_pelanggan` (`no_pelanggan`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id_penjualan`),
  ADD KEY `no_pelanggan` (`no_pelanggan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `id_penjualan` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD CONSTRAINT `penjualan_ibfk_1` FOREIGN KEY (`no_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
