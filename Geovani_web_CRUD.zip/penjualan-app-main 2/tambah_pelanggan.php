<?php
include 'koneksi.php';

function generateNoPelanggan($koneksi) {
  $result = mysqli_query($koneksi, "SELECT MAX(RIGHT(no_pelanggan, 3)) AS maxKode FROM pelanggan");
  $data = mysqli_fetch_assoc($result);
  $kode = (int)$data['maxKode'] + 1;
  return "PL" . str_pad($kode, 3, '0', STR_PAD_LEFT);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $no_pelanggan = generateNoPelanggan($koneksi);
  $nama = $_POST['nama_pelanggan'];
  $alamat = $_POST['alamat'];

  $stmt = $koneksi->prepare("INSERT INTO pelanggan (no_pelanggan, nama_pelanggan, alamat) VALUES (?, ?, ?)");
  $stmt->bind_param("sss", $no_pelanggan, $nama, $alamat);
  $stmt->execute();

  header("Location: tampil_pelanggan.php");
  exit;
}
?>
<!-- HTML form sama, hanya input nama & alamat -->
