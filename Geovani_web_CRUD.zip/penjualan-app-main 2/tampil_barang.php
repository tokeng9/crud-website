<?php
include 'koneksi.php';
$keyword = $_POST['keyword'] ?? '';
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <title>Data Barang</title>
</head>

<body style="background-color: white; font-family: Arial, sans-serif; padding: 20px;">
  <div style="max-width: 800px; margin: auto;">
    <h3 style="margin-bottom: 20px;">Daftar Barang</h3>
      
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
      
      <div>
        <a href="tambah_barang.php" style="background-color: #28a745; color: white; padding: 5px 10px; text-decoration: none; border-radius: 4px; font-size: 14px;">Tambah</a>
      </div>
      <div>
        <form method="post" style="display: flex; gap: 10px;">
          <input name="keyword" value="<?= $keyword ?>" style="padding: 4px; font-size: 14px;">
          <button type="submit" style="background-color: #17a2b8; color: white; padding: 4px 10px; border: none; border-radius: 4px; font-size: 14px;">Cari</button>
          <a href="tampil_barang.php" style="background-color: #17a2b8; color: white; padding: 4px 10px; text-decoration: none; border-radius: 4px; font-size: 14px;">Clear</a>
        </form>
      </div>
    </div>

    <table border="1" style="width: 100%; border-collapse: collapse; background-color: white;">
      <thead>
        <tr style="background-color:red; color: white;">
          <th style="padding: 8px;">No</th>
          <th style="padding: 8px;">Nama Barang</th>
          <th style="padding: 8px;">Harga</th>
          <th style="padding: 8px;">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $no = 1;
        $sql = "SELECT * FROM barang WHERE nama_barang LIKE '%$keyword%' ORDER BY nama_barang";
        $query = mysqli_query($koneksi, $sql);
        while ($data = mysqli_fetch_assoc($query)) {
          echo "<tr>";
          echo "<td style='padding: 8px; text-align: center;'>{$no}</td>";
          echo "<td style='padding: 8px;'>{$data['nama_barang']}</td>";
          echo "<td style='padding: 8px;'>Rp " . number_format($data['harga'], 0, ',', '.') . "</td>";
          echo "<td style='padding: 8px; text-align: center;'>
                  <a href='ubah_barang.php?id={$data['id_barang']}' style='background-color: #ffc107; color: black; padding: 4px 8px; text-decoration: none; border-radius: 4px; font-size: 13px;'>Ubah</a>
                  <a href='hapus_barang.php?id={$data['id_barang']}' style='background-color: #dc3545; color: white; padding: 4px 8px; text-decoration: none; border-radius: 4px; font-size: 13px;' onclick='return confirm(\"Yakin ingin menghapus?\")'>Hapus</a>
                </td>";
          echo "</tr>";
          $no++;
        }
        ?>
      </tbody>
    </table>

    <div style="margin-top: 20px;">
      <a href="tambah_barang.php" style="background-color: #007bff; color: white; padding: 8px 12px; text-decoration: none; border-radius: 4px;">Tambah Barang</a>
    </div>
  </div>
</body>

</html>
