// Fungsi tambahan, seperti pengolahan form
const form = document.querySelector('form');
form.addEventListener('submit', (e) => {
 e.preventDefault();
 const nama = document.querySelector('input[name="nama"]').value;
 const alamat = document.querySelector('input[name="alamat"]').value;
 console.log(nama, alamat);
});