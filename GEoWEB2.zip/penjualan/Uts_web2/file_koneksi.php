<?php
$host = "127.0.0.1";
$port = "8889";     // PORT DEFAULT MAMP
$user = "root";     // username default MAMP
$pass = "";     // password default MAMP
$db   = "GEO_HRD2025";

try {
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi ke database gagal: " . $e->getMessage());
}
?>
