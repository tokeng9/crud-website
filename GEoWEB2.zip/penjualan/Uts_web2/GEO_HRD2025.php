<?php
// ===================================
// KONFIGURASI DATABASE (MAMP)
// ===================================
$host = "127.0.0.1";
$db   = "GEO_HRD2025";
$user = "root";      // default MAMP
$pass = "root";      // default MAMP
$port = "8889";

try {
    // Koneksi dengan PORT wajib (khas MAMP)
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}

// ===================================
// QUERY LAPORAN KARYAWAN
// ===================================
$sql = "
SELECT k.geo_nip, k.geo_nama, k.geo_tanggal_lahir,
       j.geo_kode_jabatan, j.geo_nama_jabatan,
       j.geo_gaji_pokok, j.geo_tunjangan,
       (j.geo_gaji_pokok + j.geo_tunjangan) AS total_gaji
FROM geo_karyawan k
LEFT JOIN geo_jabatan j 
ON k.geo_kode_jabatan = j.geo_kode_jabatan
ORDER BY k.geo_nip;
";

$data = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Laporan Data Karyawan</title>
    <style>
        body {
            font-family: Arial;
            background: #f0f0f0;
            padding: 20px;
        }
        .container {
            width: 85%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px #ccc;
        }
        h2 {
            text-align: center;
            margin-bottom: 25px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }
        th {
            background: #2c2c2c;
            color: white;
            padding: 10px;
        }
        td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        .right {
            text-align: right;
        }
        .money {
            color: #0072ff;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Laporan Data Karyawan</h2>

    <table>
        <tr>
            <th>NIP</th>
            <th>Nama</th>
            <th>Tanggal Lahir</th>
            <th>Kode Jabatan</th>
            <th>Nama Jabatan</th>
            <th>Gaji Pokok</th>
            <th>Tunjangan</th>
            <th>Total Gaji</th>
        </tr>

        <?php foreach ($data as $d): ?>
        <tr>
            <td><?= $d['geo_nip'] ?></td>
            <td><?= $d['geo_nama'] ?></td>
            <td><?= $d['geo_tanggal_lahir'] ?></td>
            <td><?= $d['geo_kode_jabatan'] ?></td>
            <td><?= $d['geo_nama_jabatan'] ?></td>
            <td class="right">Rp <?= number_format($d['geo_gaji_pokok'], 0, ',', '.') ?></td>
            <td class="right">Rp <?= number_format($d['geo_tunjangan'], 0, ',', '.') ?></td>
            <td class="right money">Rp <?= number_format($d['total_gaji'], 0, ',', '.') ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

</body>
</html>
